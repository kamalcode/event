﻿export interface EventImage {
    id: number;
    eventId: Number;
    imageId: number;
    description: string;
} 