﻿export interface PagedResponse {
    total: number;
    data: Event[];
}
