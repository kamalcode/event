﻿export interface Event {
    eventId: Number;
    eventName: string;
    imageId: number;
} 