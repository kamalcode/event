﻿export interface EventDate {
    id: number;
    eventId: Number;
    startDate: Date;
    endtDate: Date;
    numOfPeople: Number;
} 